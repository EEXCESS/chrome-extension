PluginHandler.registerPluginScripts([
    'TestPlugin.js',
    'TestMiniVizList.js',
    'FilterVisCategoryHex.js',
    'FilterVisTime.js',
    'FilterVizGeo.js',
    'FilterVisKeywords.js'
]);
