var UsageCollector =  {

    // Actions: chartChanged, document-link-clicked, bookmark-clicked; boomkark-created, bookmark-collection-created; 
    // config-changed, filter-created, filter-changed. filter-saved.
    // collect('chart-clicked', 'barchart')
    // collect(action, additionalInformation) + timestamp
    // --> push to stack. if stack has 10 elements, or no collection of about 10
    // --> send it to a centralized server --> what server???
    
};